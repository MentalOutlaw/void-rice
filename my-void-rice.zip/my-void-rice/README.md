this is my very own rice with dwm st and slstatus.
start by running boil-pot.sh as root
once that finishes run cook-rice.sh as root
